 <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                   
                    <li <?php     if($page_name == 'package_lists') echo "class = 'active' "; ?>>
                        <a href="index"><i class="fa fa-fw fa-user"></i> Photo Services </a>
                    </li>

                    <li>
                        <a href="customer_gallery.html"><i class="fa fa-fw fa-picture-o"></i> Gallery</a>
                    </li>




                    <li <?php     if($page_name == 'my_appointments') echo "class = 'active' "; ?>>
                        <a href="my_appointments"><i class="fa fa-fw fa-picture-o"></i> 
                        My Appointments</a>
                    </li>

                </ul>
            </div>

            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">