  <div id="viewPackage" class="modal fade" role="dialog">
                          <div class="modal-dialog">

                            <!-- Modal content-->
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>

                                  <h2>Package Details</h2>

                                  

                               </div>

                              <div  id = "package_details"> 




                              </div>


                             </form>

                            </div>

                          </div>
</div>