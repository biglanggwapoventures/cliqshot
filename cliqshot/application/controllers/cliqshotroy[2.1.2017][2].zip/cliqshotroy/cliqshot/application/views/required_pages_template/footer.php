
<br>
<br>
<br>

<br>
<br>

<div class="col-lg-12">
<h4 class="page-header">
    <i class="fa fa-picture-o"></i> Information About Photos

</h4>

All photos will be processed and stored in CD with both high-resolution and watermarked web-sharing versions.

Turnover time is between 7 - 10 business days depending on the service selected.
<br>
<br>
</div>

      <div class="col-lg-3">
      <button type="button" class="btn btn-lg btn-primary">Next</button>
      <br>
      <br>
      <br>
      </div>

      </div>



                </div>

                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="<?php echo 'http://localhost/cliqshot/cliqshot/assets/js/jquery.js'; ?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo 'http://localhost/cliqshot/cliqshot/assets/js/bootstrap.min.js'; ?>"></script>

</body>

</html>
