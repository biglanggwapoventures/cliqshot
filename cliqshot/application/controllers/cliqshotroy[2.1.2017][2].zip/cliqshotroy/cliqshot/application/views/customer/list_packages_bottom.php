 <div class="panel-body">
                                                       1.5-hour Mommy and Daddy Photo Session

                                                       3-hour Newborn and Family Photo Session

                                                       50 processed high-resolution and 50 photos for web sharing photos in a CD

                                                       Choice of six 8" x 10" or one 24" x 36" Collage Print, Photobook
                                                     </div>
                                                   </div>
                                                 </div>

                                                 <h4 class="page-header">
                                                     <i class="fa fa-picture-o"></i> Optional Add-ons

                                                 </h4>
                                                 <div class="col-sm-4">
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                          <div class="radio">
                                                   <label class="checkbox-inline">
                                                       <input type="checkbox"><h3 class="panel-title">Photography Package Preference:
                                                         </h3>
                                                   </label>
                                               </div>
                                                        </div>
                                                        <div class="panel-body">
                                                          Digital Download via Online Gallery (Included in the Package),
                                                          Digital CD Package, No Prints (Shipping and Handling Fees: $5.00),
                                                          Photography Package: CD and Prints (Shipping and Handling Fees: $10.00)
                                                        </div>
                                                      </div>
                                                    </div>

                                                    <div class="col-sm-4">
                                                       <div class="panel panel-default">
                                                           <div class="panel-heading">
                                                             <div class="radio">
                                                      <label class="checkbox-inline">
                                                          <input type="checkbox"><h3 class="panel-title">Additional Person in Group:
                                                            </h3>
                                                      </label>
                                                  </div>
                                                           </div>
                                                           <div class="panel-body">
                                                                $ 9.99 per person includes 3 more photos
                                                                <br>
                                                                <br>

                                                                <div class="form-group">

                                                                  <div class="col-sm-3">
                                                                  <input class="form-control">
                                                                </div>
                                                                <label> number of person/s</label>
                                                                </div>

                                                           </div>

                                                         </div>
                                                       </div>

                                                       <div class="col-sm-4">
                                                          <div class="panel panel-default">
                                                              <div class="panel-heading">
                                                                <div class="radio">
                                                         <label class="checkbox-inline">
                                                             <input type="checkbox"><h3 class="panel-title">Additional Time for Events:
                                                               </h3>
                                                         </label>
                                                     </div>
                                                              </div>
                                                              <div class="panel-body">
                                                                   $50 per hour
                                                                   <br>
                                                                   <br>

                                                                   <div class="form-group">

                                                                     <div class="col-sm-3">
                                                                     <input class="form-control">
                                                                   </div>
                                                                   <label> number of hour/s to be added</label>
                                                                   </div>

                                                              </div>

                                                            </div>
                                                          </div>





