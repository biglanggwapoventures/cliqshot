

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header">
                            <i class="fa fa-calendar"></i>  Pending Orders

                        </h3>

                        <div class="row">
                            
                            <div class="col-md-12">
                            
                               <div class="panel panel-red">
  
                                    
                                    <table class ='table table-striped table-condensed'>

                                    <thead>

                                        <tr>
                                            <td>Order Id
                                            <td>Package Name
                                            <td>Date Ordered
                                            <td>Event Date
                                            <td>Event Time
                                            <td>Status
                                    </thead>
                                    

                              
                                    </table>

                               </div>

                            </div>
                    </div>
                                                  